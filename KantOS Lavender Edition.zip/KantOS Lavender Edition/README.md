# About

All relevant information, credits and screenshots can be found on the theme's main [Github repo](https://github.com/antonlabz/KantOS/tree/main).

# Special Thanks

A huge thank you to Aemiii91 for all the support and answering my many questions while I was still creating the theme, and also for all their work on developing OnionOS.